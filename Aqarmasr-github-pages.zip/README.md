# عقار مصر للمقاولات والتوريدات واستصلاح الأراضي

الموقع الرسمي — منشور على GitHub Pages:
https://aqarmasrm-tech.github.io/Aqarmasr/

## محتويات المستودع
- index.html — الصفحة الرئيسية (عربي / إنجليزي)
- 404.html — صفحة الخطأ وتحويل للرئيسية
- assets/ — اللوجو، صورة الفيلم، فيلم الشركة (MP4)
- robots.txt, sitemap.xml, .nojekyll

## ملاحظة
الدومين aqarmasr.com مؤجل. لا يوجد ملف CNAME في المستودع حتى يتم ربط الدومين.
